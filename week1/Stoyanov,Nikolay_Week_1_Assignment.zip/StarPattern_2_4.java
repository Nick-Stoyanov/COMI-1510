package week1;

/**
 * This program displays a simple star pattern
 * 
 * @author Nikolay Stoyanov
 * @assignment 2.4 Star Pattern
 * @due 9/18/2022
 *
 */
public class StarPattern_2_4
{
    /**
     * 
     * Main method displays simple star pattern
     */
    public static void main(String[] args)
    {
	System.out.println("   *   ");
	System.out.println("  ***  ");
	System.out.println(" ***** ");
	System.out.println("*******");
	System.out.println(" ***** ");
	System.out.println("  ***  ");
	System.out.println("   *   ");
    } // End main

} // End class